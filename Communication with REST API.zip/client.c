#include <stdio.h>   
#include <stdlib.h>  
#include <unistd.h>    
#include <string.h>   
#include <sys/socket.h> 
#include <netinet/in.h>
#include <netdb.h>      
#include <arpa/inet.h>
#include "helpers.h"
#include "requests.h"
#include "parson.c"
#include "parson.h"

int main(int argc, char *argv[]) {

    char *message;
    char *response;
    int sockfd, ret;
    struct addrinfo hints, *result;

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    ret = getaddrinfo("ec2-3-8-116-10.eu-west-2.compute.amazonaws.com", NULL, &hints, &result);

    struct sockaddr *getAddr = result->ai_addr;
    struct sockaddr_in *serv_addr = (struct sockaddr_in*)getAddr;

    char host[300];
    sprintf(host, "ec2-3-8-116-10.eu-west-2.compute.amazonaws.com");
    
    char url[300];
    sprintf(url, "/api/v1/tema/auth/register");

    char host_ip[300];
    memset(host_ip, 0, 300);
    inet_ntop(AF_INET, &(serv_addr->sin_addr), host_ip, 300);

    char comanda[300];
    char **cookie;
    cookie = (char**)malloc(sizeof(char*));
    cookie[0] = (char*)malloc(300 * sizeof(char));

    char **token;
    token = (char**)malloc(sizeof(char*));
    token[0] = (char*)malloc(300*sizeof(char));

    char help[300];
    int i;
    int sunt_logat = 0;
    int sunt_in_librarie = 0;

    while (1) {
        //Deschid conexiunea
        sockfd = open_connection(host_ip, 8080, AF_INET, SOCK_STREAM, 0);

        memset(comanda, 0, strlen(comanda));
        scanf("%s", comanda);

        if (strncmp(comanda, "exit", 4) == 0) {
            break;
        }

        if (strncmp(comanda, "register", 8) == 0) {

            printf("%s: ","username");
            char username[300];
            scanf("%s", username);

            printf("%s: ", "password");
            char password[300];
            scanf("%s", password);

            char **payload;
            payload = (char**)malloc(sizeof(char*));
            payload[0] = (char*)malloc(300 * sizeof(char));


            char *serialized_string = NULL;
            JSON_Value *root_value = json_value_init_object();
            JSON_Object *root_object = json_value_get_object(root_value);
            json_object_set_string(root_object, "username", username);
            json_object_set_string(root_object, "password", password);
            serialized_string = json_serialize_to_string_pretty(root_value);

            strcpy(payload[0], serialized_string);

            json_free_serialized_string(serialized_string);
            json_value_free(root_value);


        message = compute_post_request(host, url,"application/json", payload, 1, NULL, 1);
        send_to_server(sockfd, message);
        response = receive_from_server(sockfd);
        puts(response);
    }else 
        if ((strncmp(comanda, "login", 5) == 0) && (sunt_logat == 0)) {

            sunt_logat = 1;
            printf("%s: ","username");
            char username[300];
            scanf("%s", username);

            printf("%s: ", "password");
            char password[300];
            scanf("%s", password);

            char **payload;
            payload = (char**)malloc(sizeof(char*));
            payload[0] = (char*)malloc(300 * sizeof(char));


            char *serialized_string = NULL;
            JSON_Value *root_value = json_value_init_object();
            JSON_Object *root_object = json_value_get_object(root_value);
            json_object_set_string(root_object, "username", username);
            json_object_set_string(root_object, "password", password);
            serialized_string = json_serialize_to_string_pretty(root_value);

            strcpy(payload[0], serialized_string);

            json_free_serialized_string(serialized_string);
            json_value_free(root_value);


        message = compute_post_request(host, "/api/v1/tema/auth/login","application/json", payload, 1, NULL, 1);
        send_to_server(sockfd, message);
        response = receive_from_server(sockfd);
        puts(response);

        char eroare[300];
        memcpy(eroare, response + 9, 3);
        if (strncmp(eroare, "400", 3) == 0) {
            sunt_logat = 0;
        }
        memset(eroare, 0, 300);

        int count = 0;
        for (i = 0; i < strlen(response); i++) {
            if (response[i] == '\n') {
                count ++;
            }
            if (count == 8) {
                break;
            }
        }
        memcpy(help, response + i + 13, sizeof(help));

        for (i = 0; i < strlen(help); i++) {
            if (help[i] == ';') {
                break;
            }
        }
        memset(cookie[0], 0, 300);
        memcpy(cookie[0], help, i);

    } else
        if ((strncmp(comanda, "enter_library", 13) == 0)) {
            if (sunt_in_librarie == 1) {
                printf("Esti deja in librarie!\n");
            } else
                if (sunt_logat == 0) {
                    printf("Nu sunteti logat!\n");
                } else {
                    sunt_in_librarie = 1;

            message = compute_get_or_delete_request(host, "/api/v1/tema/library/access", NULL, cookie, 1, 1);
            send_to_server(sockfd, message);
            response = receive_from_server(sockfd);
            puts(response);
            int count = 0;
                for (i = 0; i < strlen(response); i++) {
                    if (response[i] == '\n') {
                        count ++;
                    }
                    if (count == 14) {
                        break;
                    }
                }
            char help2[300];
            memcpy(help2, response + i + 11, sizeof(help2));

            for (i =0; i < strlen(help2); i++) {
                if (help2[i] == '"') {
                    break;
                }
            }
            memset(token[0], 0, 300);
            memcpy(token[0], "Authorization: Bearer ", strlen("Authorization: Bearer "));
            strncat(token[0], help2, i);

        }
    }
    else
        if (strncmp(comanda, "logout", 6) == 0) {
            sunt_logat = 0;
            sunt_in_librarie = 0;

            message = compute_get_or_delete_request(host, "/api/v1/tema/auth/logout", NULL, cookie, 1, 1);
            send_to_server(sockfd, message);
            response = receive_from_server(sockfd);
            puts(response);

        }
    else
        if (strncmp(comanda, "get_books", 9) == 0) {
            if (sunt_in_librarie == 0) {
                printf("Nu sunteti intr-o librarie!\n");
            } else {

            message = compute_get_or_delete_request(host, "/api/v1/tema/library/books", NULL, token, 1, 1);
            printf("Message: %s\n", message);
            send_to_server(sockfd, message);
            response = receive_from_server(sockfd);
            puts(response);
        }
    }
    else
        if (strncmp(comanda, "get_book", 8) == 0) {
            if (sunt_in_librarie == 0) {
                printf("Nu sunteti intr-o librarie!\n");
            } else {

            char id[20];
            printf("id: ");
            scanf("%s", id);
            char path[300];
            sprintf(path, "/api/v1/tema/library/books/");
            strcat(path, id);
            printf("PATH\n");
            puts(path);

            message = compute_get_or_delete_request(host, path, NULL, token, 1, 1);
            send_to_server(sockfd, message);
            response = receive_from_server(sockfd);
            puts(response);
        }
    }
    else
        if (strncmp(comanda, "add_book", 8) == 0) {
            if (sunt_in_librarie == 0) {
                printf("Nu sunteti intr-o librarie!\n");
            } else {

            char title[100];
            char author[100];
            char genre[100];
            char page_count[100];
            char publisher[100];

            printf("title: ");
            scanf("%s", title);
            printf("\n");

            printf("author: ");
            scanf("%s", author);
            printf("\n");

            printf("genre: ");
            scanf("%s", genre);
            printf("\n");


            printf("publisher: ");
            scanf("%s", publisher);
            printf("\n");

            printf("page_count: ");
            scanf("%s", page_count);
            printf("\n");

            char **payload;
            payload = (char**)malloc(sizeof(char*));
            payload[0] = (char*)malloc(300 * sizeof(char));


            char *serialized_string = NULL;
            JSON_Value *root_value = json_value_init_object();
            JSON_Object *root_object = json_value_get_object(root_value);
            json_object_set_string(root_object, "title", title);
            json_object_set_string(root_object, "author", author);
            json_object_set_string(root_object, "genre", genre);
            json_object_set_string(root_object, "publisher", publisher);
            json_object_set_string(root_object, "page_count", page_count);
            serialized_string = json_serialize_to_string_pretty(root_value);

            strcpy(payload[0], serialized_string);

            json_free_serialized_string(serialized_string);
            json_value_free(root_value);


            message = compute_post_request(host, "/api/v1/tema/library/books","application/json", payload, 1, token, 1);
            send_to_server(sockfd, message);
            response = receive_from_server(sockfd);
            puts(response);
        }
    }
    else
        if (strncmp(comanda, "delete_book", 11) == 0) {
            if (sunt_in_librarie == 0) {
                printf("Nu sunteti intr-o librarie!\n");
            } else {
            char id[20];
            printf("id: ");
            scanf("%s", id);
            char path[300];
            sprintf(path, "/api/v1/tema/library/books/");
            strcat(path, id);
            printf("PATH\n");
            puts(path);

            message = compute_get_or_delete_request(host, path, NULL, token, 1, 2);
            send_to_server(sockfd, message);
            response = receive_from_server(sockfd);
            puts(response);
        }
    }

    close(sockfd);
    }

    return 0;
}